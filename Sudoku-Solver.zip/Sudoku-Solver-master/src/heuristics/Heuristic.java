package heuristics;

import cmd.Move;

public interface Heuristic {

	Move getSolution();
	
	
}
