package componentsModel;

public class GridModel {
   
}
