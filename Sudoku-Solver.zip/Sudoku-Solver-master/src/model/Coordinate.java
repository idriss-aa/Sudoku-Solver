package model;

public interface Coordinate {

	int getX();

	int getY();
	
	String toString();
}
