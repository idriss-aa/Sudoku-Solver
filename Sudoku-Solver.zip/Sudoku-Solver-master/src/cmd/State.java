package cmd;

public enum State {
	DO,
	UNDO
}
